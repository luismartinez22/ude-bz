'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
            let scanningParameters = {
                TableName: "Cart",
                FilterExpression:"cookie = :cookie",
                ExpressionAttributeValues:{
                    ":cookie": event.cookie
                    //":cookie": "luis456"
                },
                
            };
            
            docClient.scan(scanningParameters, function(err, data){
                if(err){
                    callback(err, null);
                }else{
                    for(var i = 0; i < data.Count;i++){
                        console.log(data.Items[i].id);
                            var params = {
                            TableName:"Cart",
                            Key: {"id": data.Items[i].id,
                            },
                        };
                        docClient.delete(params, function(err, data) {
                            if (err) {
                                console.error("Unable to delete item. Error JSON:", JSON.stringify(err, null, 2));
                            }
                        });
                    }
                }
            });
}

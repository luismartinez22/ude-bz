'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    let scanningParameters = {
        TableName: "Article",
        Limit: 10000
    };
    docClient.scan(scanningParameters, function(err, data){
        if(err){
            callback(err, null);
        }else{
            var num1 = 0;
            while(num1 <= data.ScannedCount){
                let scanningParameters = {
                    TableName: "Article",
                    Limit: 10000
                };
                docClient.scan(scanningParameters, function(err, data){
                    if(err){
                        callback(err, null);
                    }else{
                        var num = 0;
                       while(num <= data.ScannedCount){
                            if(data.Items[num].id == event.id){
                            //if(data.Items[num].id == 7){
                                callback(null, data.Items[num]);
                                return;
                            }else{
                                num++;
                            }
                       } 
                    }
                });
                num1++;
            }
        }
    });
}

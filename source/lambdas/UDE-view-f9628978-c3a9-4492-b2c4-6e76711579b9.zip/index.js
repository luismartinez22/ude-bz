'use strict';

console.log('Loading function');

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    
    var params = {
        TableName: "Article",
        Key: {"id": + event.id},
        //Key: {"id": 7},
    };
    docClient.get(params, function(err, data){
        if(err){
            callback(err, null);
        }else{
            callback(null, data.Item);
        }
    });
}

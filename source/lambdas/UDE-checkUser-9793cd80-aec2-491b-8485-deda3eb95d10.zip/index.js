'use strict';

console.log('Loading function');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    var params2 = {
                TableName: "Token",
                Key: {"token": event.token},
                }
    docClient.get(params2, function(err, data){
        if(err){
            callback(err, null);
        }else{
            var datetime = Math.floor(Date.now() / 1000);
            if(data.Item.expiration > datetime){
                callback(null, data);
            }else{
                callback("Token has expired",null);
            }
            
        }
    });
};

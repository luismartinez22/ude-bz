'use strict';
console.log('Loading function');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = (event, context, callback) => {
    //console.log(event.username);
    var params = {
        TableName: "User",
        Key: {"username": event.username},
        //Key: {"username": "luism"},
    };
    docClient.get(params, function(err, data){
        if(data.Item === undefined){
            callback("User does not exist.",null);
        }else{
        if(err){
            callback(err, null);
        }else{
            if(data.Item.password == event.password){
                var datetime = Math.floor(Date.now() / 1000) + 600;
                var string = data.Item.username + datetime;
                var buffer2 = new Buffer(string);
                var toBase64 = buffer2.toString('base64');
                callback(null, "Auth_token: "+ toBase64);
                var params = {
                    Item: {
                        token: toBase64,
                        expiration: datetime,
                        username: data.Item.username
                    },
                    TableName: 'Token'
                };
                
                docClient.put(params, function(err, data){
                    if(err){
                        callback(err, null);
                    }else{
                        callback(null, data);
                    }
                });
            }else{
                callback("Wrong password.",null);
            }
        }
        }
    });
    
}
